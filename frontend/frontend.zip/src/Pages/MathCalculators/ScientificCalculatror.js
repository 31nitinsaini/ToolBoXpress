import React, { useState } from 'react';
import Header from '../../Components/Header';
import Footer from '../../Components/Footer';

const ScientificCalculator = () => {
  const [input, setInput] = useState('');

  const handleButtonClick = (value) => {
    setInput((prevInput) => prevInput + value);
  };

  const clearInput = () => {
    setInput('');
  };

  const calculateResult = () => {
    try {
      const result = eval(input);
      setInput(result.toString());
    } catch (error) {
      setInput('Error');
    }
  };

  const handleTrigFunction = (func) => {
    const radians = eval(input); // Assumes the input is in degrees
    try {
      const result = Math[func](radians * (Math.PI / 180)); // Convert degrees to radians
      setInput(result.toString());
    } catch (error) {
      setInput('Error');
    }
  };

  const handleSquareRoot = () => {
    try {
      const result = Math.sqrt(eval(input));
      setInput(result.toString());
    } catch (error) {
      setInput('Error');
    }
  };

  const calculatorStyles = {
    width: '320px',
    margin: '0 auto',
    border: '1px solid #000',
    padding: '10px',
    borderRadius: '5px',
    boxShadow: '0 0 5px rgba(0, 0, 0, 0.2)',
    backgroundColor: '#fff',
    color: '#000',
  };

  const buttonStyles = {
    width: '50px',
    height: '50px',
    fontSize: '20px',
    margin: '5px',
    backgroundColor: '#0073e6',
    border: '1px solid #000',
    color: '#fff',
    cursor: 'pointer',
  };

  const inputStyles = {
    width: '100%',
    marginBottom: '10px',
    fontSize: '24px',
    padding: '5px',
  };

  return (
    <>
      <Header />
      <main>
        <div style={calculatorStyles}>
          <input
            type="text"
            value={input}
            readOnly
            style={inputStyles}
          />
          <div>
            <button onClick={() => handleButtonClick('7')} style={buttonStyles}>7</button>
            <button onClick={() => handleButtonClick('8')} style={buttonStyles}>8</button>
            <button onClick={() => handleButtonClick('9')} style={buttonStyles}>9</button>
            <button onClick={() => handleButtonClick('+')} style={buttonStyles}>+</button>
          </div>
          <div>
            <button onClick={() => handleButtonClick('4')} style={buttonStyles}>4</button>
            <button onClick={() => handleButtonClick('5')} style={buttonStyles}>5</button>
            <button onClick={() => handleButtonClick('6')} style={buttonStyles}>6</button>
            <button onClick={() => handleButtonClick('-')} style={buttonStyles}>-</button>
          </div>
          <div>
            <button onClick={() => handleButtonClick('1')} style={buttonStyles}>1</button>
            <button onClick={() => handleButtonClick('2')} style={buttonStyles}>2</button>
            <button onClick={() => handleButtonClick('3')} style={buttonStyles}>3</button>
            <button onClick={() => handleButtonClick('*')} style={buttonStyles}>*</button>
          </div>
          <div>
            <button onClick={clearInput} style={buttonStyles}>C</button>
            <button onClick={() => handleButtonClick('0')} style={buttonStyles}>0</button>
            <button onClick={() => handleButtonClick('.')} style={buttonStyles}>.</button>
            <button onClick={() => handleButtonClick('/')} style={buttonStyles}>/</button>
          </div>
          <div>
            <button onClick={handleSquareRoot} style={buttonStyles}>√</button>
            <button onClick={() => handleButtonClick('^')} style={buttonStyles}>^</button>
            <button onClick={() => handleButtonClick('log(')} style={buttonStyles}>log</button>
            <button onClick={() => handleButtonClick('exp(')} style={buttonStyles}>exp</button>
          </div>
          <div>
            <button onClick={() => handleTrigFunction('sin')} style={buttonStyles}>sin</button>
            <button onClick={() => handleTrigFunction('cos')} style={buttonStyles}>cos</button>
            <button onClick={() => handleTrigFunction('tan')} style={buttonStyles}>tan</button>
            <button onClick={() => handleButtonClick('(')} style={buttonStyles}>(</button>
            <button onClick={() => handleButtonClick(')')} style={buttonStyles}>)</button>
          </div>
          <div>
            <button onClick={calculateResult} style={{ ...buttonStyles, backgroundColor: '#ff9900' }}>=</button>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default ScientificCalculator;
